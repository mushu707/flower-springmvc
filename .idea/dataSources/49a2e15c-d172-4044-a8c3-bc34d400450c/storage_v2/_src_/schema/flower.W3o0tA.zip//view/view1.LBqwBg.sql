create definer = root@localhost view view1 as
select `c`.`name` AS `顾客名`, `o`.`commodity` AS `商品`, `s`.`name` AS `商店`
from ((`flower`.`customer` `c` join `flower`.`order` `o`)
         join `flower`.`store` `s`)
where ((`c`.`id` = `o`.`c_id`) and (`o`.`s_id` = `s`.`id`));

