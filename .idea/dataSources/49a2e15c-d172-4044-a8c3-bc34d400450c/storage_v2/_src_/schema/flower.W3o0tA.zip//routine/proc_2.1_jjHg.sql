create
    definer = root@localhost procedure proc_2(IN aname varchar(10))
BEGIN
	#Routine body goes here...
	-- 使用管理员姓名查询该管理员管理的商店的销售量与销售的鲜花
	select a.name as '管理员', s.name as '商店',f.name as '鲜花',f.color as '颜色', m.number as '销售量'
	from admin as a, store as s, flower as f, market as m
	-- 连接查询
	where a.id = s.a_id 
	and s.id = m.s_id		
	and f.id = m.f_id
	and a.name = `aname`;
END;

