create definer = root@localhost trigger insertFlower
    before insert
    on flower
    for each row
begin
	if (new.name in (select name from flower) and new.color in (select color from flower))
	then signal sqlstate 'HY000' set message_text = '已存在此鲜花信息!';
	end if;
end;

