create
    definer = root@localhost procedure proc_3(IN sid varchar(10))
BEGIN
	#Routine body goes here...
	-- 使用商店号查询与该商店地址相同的顾客信息
	select s.name as '商店', s.address as '商店地址', 
	c.name as '顾客',c.address as '顾客地址'
	from store as s, customer as c
	where s.address = c.address
	and s.id = sid;
END;

