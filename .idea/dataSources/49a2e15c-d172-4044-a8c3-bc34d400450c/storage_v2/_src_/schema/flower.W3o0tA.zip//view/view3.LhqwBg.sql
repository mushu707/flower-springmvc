create definer = root@localhost view view3 as
select `s`.`name` AS `商店`, `f`.`name` AS `鲜花`, `f`.`color` AS `颜色`, `m`.`number` AS `数量`
from ((`flower`.`store` `s` join `flower`.`flower` `f`)
         join `flower`.`market` `m`)
where ((`s`.`id` = `m`.`s_id`) and (`f`.`id` = `m`.`f_id`))
order by `m`.`number` desc;

