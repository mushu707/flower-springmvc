create definer = root@localhost trigger updateNumber
    after update
    on market
    for each row
begin
	update flower
	set stock = stock - (new.number - old.number)
	where new.f_id = flower.id;
end;

