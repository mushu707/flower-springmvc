create definer = root@localhost trigger checkCustomer
    before insert
    on customer
    for each row
begin
	if (new.age <= 12)
	then signal sqlstate 'HY000' set message_text = '顾客年龄不能小于12岁!';
	end if;
end;

