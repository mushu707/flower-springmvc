create definer = root@localhost trigger updateAdmin
    after update
    on admin
    for each row
begin
	if(new.age <25 or new.age > 45)
	then signal sqlstate 'HY000' set message_text = '更新错误:管理员年龄不能小于25或大于45!';
	end if;
end;

