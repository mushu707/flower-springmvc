create definer = root@localhost trigger test1
    before insert
    on `order`
    for each row
BEGIN
IF(new.amount = 0)
then signal sqlstate 'HY000' set message_text = '订单金额不能为0!';
end if;
END;

