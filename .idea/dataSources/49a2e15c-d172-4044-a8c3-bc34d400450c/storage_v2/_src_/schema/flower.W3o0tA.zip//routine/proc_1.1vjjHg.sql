create
    definer = root@localhost procedure proc_1(IN cid varchar(10))
BEGIN
	-- 使用ID查询某个顾客订购的商品和付款金额
	select c.id as '顾客号', c.name as '顾客', o.commodity as '商品', o.amount as '金额'
	from customer as c, `order` as o
	where c.id = o.c_id
	and c.id = cid;	-- 筛选输入的参数信息
END;

