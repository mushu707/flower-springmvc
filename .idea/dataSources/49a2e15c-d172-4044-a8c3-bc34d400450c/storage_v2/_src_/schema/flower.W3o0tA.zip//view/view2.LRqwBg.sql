create definer = root@localhost view view2 as
select `c`.`id` AS `顾客号`, `c`.`name` AS `顾客`, count(`o`.`id`) AS `订单数`, sum(`o`.`amount`) AS `总金额`
from `flower`.`customer` `c`
         join `flower`.`order` `o`
where (`c`.`id` = `o`.`c_id`)
group by `c`.`name`, `c`.`id`;

